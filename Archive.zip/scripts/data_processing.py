import pandas as pd

def load_data(file_path, position):
    # Load the Excel file
    data = pd.read_excel(file_path)

    # Filter data based on position
    if position == 'WR':
        data = data[data['Position'] == 'WR']
    elif position == 'QB':
        data = data[data['Position'] == 'QB']
    elif position == 'RB':
        data = data[data['Position'] == 'RB']
    
    return data

def preprocess_data(data, position):
    # General preprocessing steps
    data = data.dropna()

    # Position-specific preprocessing
    if position == 'WR':
        # WR-specific preprocessing
        pass
    elif position == 'QB':
        # QB-specific preprocessing
        pass
    elif position == 'RB':
        # RB-specific preprocessing
        pass

    return data