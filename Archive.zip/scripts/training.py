import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import TensorDataset, DataLoader
import numpy as np

def prepare_data_for_lstm(df, features, target, seq_length=3):
    X = []
    y = []

    for player in df['Player'].unique():
        player_data = df[df['Player'] == player]
        for i in range(len(player_data) - seq_length):
            X.append(player_data[features].iloc[i:i+seq_length].values)
            y.append(player_data[target].iloc[i+seq_length])
    
    # Convert lists to numpy arrays before creating tensors
    X = np.array(X)
    y = np.array(y)

    X = torch.tensor(X, dtype=torch.float32)
    y = torch.tensor(y, dtype=torch.float32).view(-1, 1)
    
    return X, y
def train_model(model, X_train, y_train, epochs=1000, learning_rate=0.001):
    criterion = nn.MSELoss()
    optimizer = optim.Adam(model.parameters(), lr=learning_rate)

    train_dataset = TensorDataset(X_train, y_train)
    train_loader = DataLoader(train_dataset, batch_size=32, shuffle=True)

    for epoch in range(epochs):
        model.train()
        for inputs, targets in train_loader:
            outputs = model(inputs)
            loss = criterion(outputs, targets)

            optimizer.zero_grad()
            loss.backward()
            optimizer.step()

        if (epoch + 1) % 100 == 0:
            print(f'Epoch [{epoch+1}/{epochs}], Loss: {loss.item():.4f}')
