import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import TensorDataset, DataLoader
from sklearn.preprocessing import StandardScaler

def train_model(model, X_train, y_train, epochs=1000, learning_rate=0.001, batch_size=32, patience=10):
    # Use GPU if available, else fallback to CPU
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    model.to(device)
    
    # Reshape the data to 2D for normalization
    num_samples, sequence_length, num_features = X_train.shape
    X_train_reshaped = X_train.reshape(-1, num_features)
    
    # Normalize the data
    scaler = StandardScaler()
    X_train_reshaped = scaler.fit_transform(X_train_reshaped)
    
    # Reshape back to the original 3D shape
    X_train_scaled = X_train_reshaped.reshape(num_samples, sequence_length, num_features)
    
    # Convert to PyTorch tensors
    train_inputs = torch.tensor(X_train_scaled, dtype=torch.float32)
    train_targets = torch.tensor(y_train, dtype=torch.float32).unsqueeze(1)
    
    # Create DataLoader
    train_loader = DataLoader(TensorDataset(train_inputs, train_targets), batch_size=batch_size, shuffle=True)
    
    # Define loss function and optimizer
    criterion = nn.MSELoss()
    optimizer = optim.Adam(model.parameters(), lr=learning_rate, weight_decay=1e-5)
    scheduler = optim.lr_scheduler.ReduceLROnPlateau(optimizer, 'min', patience=3, factor=0.5, verbose=True)
    
    best_loss = float('inf')
    patience_counter = 0
    
    for epoch in range(epochs):
        model.train()
        running_loss = 0.0
        
        for inputs, targets in train_loader:
            inputs, targets = inputs.to(device), targets.to(device)
            
            # Zero the parameter gradients
            optimizer.zero_grad()
            
            # Forward pass
            outputs = model(inputs)
            loss = criterion(outputs, targets)
            
            # Backward pass and optimize
            loss.backward()
            optimizer.step()
            
            running_loss += loss.item()
        
        epoch_loss = running_loss / len(train_loader)
        scheduler.step(epoch_loss)
        
        print(f'Epoch [{epoch+1}/{epochs}], Loss: {epoch_loss:.4f}')
        
        # Early stopping
        if epoch_loss < best_loss:
            best_loss = epoch_loss
            patience_counter = 0
            torch.save(model.state_dict(), 'best_model.pth')
        else:
            patience_counter += 1
            if patience_counter >= patience:
                print("Early stopping triggered")
                break
