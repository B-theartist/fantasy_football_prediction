import torch
import numpy as np
import pandas as pd
import openpyxl

def save_predictions(predictions_df, existing_file_path, file_path):
    # Load the existing Excel file with openpyxl
    workbook = openpyxl.load_workbook(existing_file_path)
    sheet = workbook.active

    # Replace the first two columns with new data
    for i, (player, predicted) in enumerate(zip(predictions_df['Player'], predictions_df['Predicted_FantPt/G']), start=2):
        sheet[f'A{i}'].value = player
        sheet[f'B{i}'].value = predicted

    # Save the updated Excel file
    workbook.save(file_path)

def predict(model, X):
    model.eval()
    with torch.no_grad():
        predictions = model(torch.tensor(X, dtype=torch.float32)).numpy()
    return predictions