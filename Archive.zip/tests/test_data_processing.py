import pandas as pd
import numpy as np
from sklearn.model_selection import StratifiedShuffleSplit

def balance_dataset(df, target, n_samples=1000):
    bins = pd.qcut(df[target], q=5)
    balanced_df = df.groupby(bins, observed=True).apply(lambda x: x.sample(n=min(len(x), n_samples), random_state=42)).reset_index(drop=True)
    return balanced_df

def stratified_sampling(df, target, test_size=0.2, random_state=42):
    df['FantPt_bin'] = pd.qcut(df[target], q=5, labels=False)
    split = StratifiedShuffleSplit(n_splits=1, test_size=test_size, random_state=random_state)
    for train_index, test_index in split.split(df, df[['Year', 'FantPt_bin']]):
        strat_train_set = df.loc[train_index]
        strat_test_set = df.loc[test_index]
    strat_train_set = strat_train_set.drop(columns=['FantPt_bin'])
    strat_test_set = strat_test_set.drop(columns=['FantPt_bin'])
    return strat_train_set, strat_test_set