import os
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from scripts.training import train_model
from scripts.evaluation import evaluate_model, plot_correlation_matrix, plot_distribution
from scripts.prediction import predict, save_predictions
from scripts.feature_engineering import preprocess_data, add_rolling_averages, shift_target, add_season_flags
from scripts.data_processing import load_data
from scripts.model import FantasyFootballLSTM
import torch
import numpy as np

# Define paths
data_path = 'data/cleaned_fantasy_football_data.xlsx'
results_path = 'results'
model_dir = 'models'
predictions_dir = os.path.join(results_path, 'predictions_2024')

# Create directories if they don't exist
os.makedirs(results_path, exist_ok=True)
os.makedirs(model_dir, exist_ok=True)
os.makedirs(predictions_dir, exist_ok=True)

# Load the data
df = pd.read_excel(data_path)
positions = ['WR', 'QB', 'RB']
models = {}
scalers = {}

def prepare_data_for_lstm(df, features, target, seq_length=3):
    X = []
    y = []

    for player in df['Player'].unique():
        player_data = df[df['Player'] == player]
        for i in range(len(player_data) - seq_length):
            X.append(player_data[features].iloc[i:i+seq_length].values)
            y.append(player_data[target].iloc[i+seq_length])
    
    # Convert lists to numpy arrays before creating tensors
    X = np.array(X)
    y = np.array(y)

    X = torch.tensor(X, dtype=torch.float32)
    y = torch.tensor(y, dtype=torch.float32).view(-1, 1)
    
    return X, y

for position in positions:
    # Preprocess and feature engineering for each position
    df_position = preprocess_data(df.copy(), position)
    df_position = add_rolling_averages(df_position, position)
    df_position = add_season_flags(df_position)

    # Save 2023 data before shifting the target
    df_2023 = df_position[df_position['Year'] == 2023].copy()
    player_names_2023 = df_2023['Player'].reset_index(drop=True)
    df_2023 = df_2023.drop(columns=['Player'])

    # Apply shift_target to remove rows with NaN target values
    df_position = shift_target(df_position)

    # Reset the index to ensure sequential indexing
    df_position = df_position.reset_index(drop=True)

    # Define features and target
    if position == 'WR':
        feature_names = ['Year', 'Age', 'G', 'Tgt', 'Rec', 'RecYds', 'RecTD', 'TD/G', 'RecYds/G',
                         'FantPt/G', 'Tgt/G', 'FantPt/GLast2Y', 'FantPt/GLast3Y',
                         'Tgt/GLast2Y', 'Tgt/GLast3Y', 'RecYds/GLast2Y', 'RecYds/GLast3Y',
                         '#ofY']
    elif position == 'QB':
        feature_names = ['Year', 'Age', 'G', 'Cmp', 'PassAtt', 'PassYds', 'PassTD', 'TD/G', 'PassYds/G',
                         'FantPt/G', 'Cmp/G', 'FantPt/GLast2Y', 'FantPt/GLast3Y',
                         'Cmp/GLast2Y', 'Cmp/GLast3Y', 'PassYds/GLast2Y', 'PassYds/GLast3Y',
                         '#ofY']
    elif position == 'RB':
        feature_names = ['Year', 'Age', 'G', 'RushAtt', 'RushYds', 'RushTD', 'TD/G', 'RushYds/G',
                         'FantPt/G', 'RushAtt/G', 'FantPt/GLast2Y', 'FantPt/GLast3Y',
                         'RushAtt/GLast2Y', 'RushAtt/GLast3Y', 'RushYds/GLast2Y', 'RushYds/GLast3Y',
                         '#ofY']
        
    target = 'NextYearFantPt/G'

    # Prepare data for LSTM
    X, y = prepare_data_for_lstm(df_position, feature_names, target)

    # Split the data into training and test sets
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    # Filter data for 2023 to be used for prediction later
    X_2023 = df_2023[feature_names].values  # Convert DataFrame to numpy array

    # Standardize the data
    scaler = StandardScaler()
    # Reshape for scaling
    num_samples, seq_len, num_features = X_train.shape
    X_train = scaler.fit_transform(X_train.reshape(-1, num_features)).reshape(num_samples, seq_len, num_features)
    X_test = scaler.transform(X_test.reshape(-1, num_features)).reshape(X_test.shape[0], seq_len, num_features)
    X_2023 = scaler.transform(X_2023).reshape(X_2023.shape[0], 1, num_features)

    # Convert numpy arrays to tensors
    X_train = torch.tensor(X_train, dtype=torch.float32)
    X_test = torch.tensor(X_test, dtype=torch.float32)
    X_2023 = torch.tensor(X_2023, dtype=torch.float32)

    # Debugging: Print shapes and types of X_train and y_train
    print(f"Position: {position}")
    print(f"X_train shape: {X_train.shape}, type: {type(X_train)}, dtype: {X_train.dtype}")
    print(f"y_train shape: {y_train.shape}, type: {type(y_train)}, dtype: {y_train.dtype}")

    # Train the model
    input_dim = X_train.shape[2]
    hidden_dim = 128  # Set hidden dimension
    num_layers = 2  # Set number of LSTM layers
    model = FantasyFootballLSTM(input_dim, hidden_dim, num_layers)
    train_model(model, X_train, y_train, epochs=1000, learning_rate=0.001)

    # Save the model
    model_path = os.path.join(model_dir, f'{position}_trained_model.pth')
    torch.save(model.state_dict(), model_path)

    # Evaluate the model
    evaluate_model(model, X_test, y_test, X_train, y_train)

    # Plot correlation matrix
    plot_correlation_matrix(df_position, feature_names + [target], results_path)

    # Make predictions for the test data
    y_test_pred = predict(model, X_test)

    # Make predictions for 2024 data
    predictions_2023 = predict(model, X_2023)
    predictions_df = pd.DataFrame(predictions_2023, columns=['Predicted_FantPt/G'])

    # Ensure player names are included in predictions
    predictions_df['Player'] = player_names_2023
    predictions_path = os.path.join(predictions_dir, f'{position}_predictions_2024.xlsx')
    save_predictions(predictions_df, predictions_path)
    print(f"Predictions for 2024 for {position} saved to '{predictions_path}'")

    # Plot distribution curve for actual vs predicted values
    plot_distribution(y_test, y_test_pred, results_path)

print(f"Distribution curve plot saved to '{results_path}/distribution_curve.png'")
